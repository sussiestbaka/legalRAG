from __future__ import annotations

from django.http import HttpRequest

from allauth.socialaccount.adapter import get_adapter
from allauth.socialaccount.providers.oauth2.views import (
    OAuth2Adapter,
    OAuth2CallbackView,
    OAuth2LoginView,
)


class DigitalOceanOAuth2Adapter(OAuth2Adapter):
    provider_id = "digitalocean"
    access_token_url = "https://cloud.digitalocean.com/v1/oauth/token"  # nosec
    authorize_url = "https://cloud.digitalocean.com/v1/oauth/authorize"
    profile_url = "https://api.digitalocean.com/v2/account"

    def complete_login(self, request: HttpRequest, app, token, **kwargs):
        headers = {"Authorization": f"Bearer {token.token}"}
        with get_adapter().get_requests_session() as sess:
            resp = sess.get(self.profile_url, headers=headers)
            extra_data = resp.json()
        return self.get_provider().sociallogin_from_response(request, extra_data)


oauth2_login = OAuth2LoginView.adapter_view(DigitalOceanOAuth2Adapter)
oauth2_callback = OAuth2CallbackView.adapter_view(DigitalOceanOAuth2Adapter)
