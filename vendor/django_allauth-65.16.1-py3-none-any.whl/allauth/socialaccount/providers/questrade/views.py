from __future__ import annotations

from django.http import HttpRequest

from allauth.socialaccount.adapter import get_adapter
from allauth.socialaccount.providers.oauth2.views import (
    OAuth2Adapter,
    OAuth2CallbackView,
    OAuth2LoginView,
)


class QuestradeOAuth2Adapter(OAuth2Adapter):
    provider_id = "questrade"
    access_token_url = "https://login.questrade.com/oauth2/token"  # nosec
    authorize_url = "https://login.questrade.com/oauth2/authorize"

    def complete_login(self, request: HttpRequest, app, token, **kwargs):
        api_server = kwargs.get("response", {}).get(
            "api_server", "https://api01.iq.questrade.com/"
        )
        headers = {"Authorization": f"Bearer {token.token}"}
        with get_adapter().get_requests_session() as sess:
            resp = sess.get(f"{api_server}v1/accounts", headers=headers)
            resp.raise_for_status()
            data = resp.json()
        data.update(kwargs)
        return self.get_provider().sociallogin_from_response(request, data)


oauth2_login = OAuth2LoginView.adapter_view(QuestradeOAuth2Adapter)
oauth2_callback = OAuth2CallbackView.adapter_view(QuestradeOAuth2Adapter)
